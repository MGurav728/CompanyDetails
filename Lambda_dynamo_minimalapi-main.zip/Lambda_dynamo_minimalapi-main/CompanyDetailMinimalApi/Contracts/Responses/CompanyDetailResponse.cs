﻿using CompanyDetailMinimalApi.Contracts.Requests;

namespace CompanyDetailMinimalApi.Contracts.Responses
{
    public class CompanyDetailResponse:CompanyDetailCreateRequest
    {
        
    }
}
