﻿using CompanyDetailMinimalApi.Contracts.Requests;

namespace CompanyDetailMinimalApi.Contracts.Responses
{
    public class ContactDetailResponse : ContactDetailRequest
    {

    }
}
