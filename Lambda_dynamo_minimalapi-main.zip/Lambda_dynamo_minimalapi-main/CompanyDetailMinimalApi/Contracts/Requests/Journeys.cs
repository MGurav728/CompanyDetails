﻿namespace CompanyDetailMinimalApi.Contracts.Requests
{
    public class Journeys
    {
        public Caregiving Caregiving { get; set; }
        public Parenting Parenting { get; set; }
    }
}
