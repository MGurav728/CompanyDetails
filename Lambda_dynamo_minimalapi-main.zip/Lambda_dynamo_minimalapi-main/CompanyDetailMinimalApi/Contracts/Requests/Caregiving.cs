﻿namespace CompanyDetailMinimalApi.Contracts.Requests
{
    public class Caregiving
    {
        public bool? Enabled { get; set; }
        public List<string> Partners { get; set; }
    }
}
