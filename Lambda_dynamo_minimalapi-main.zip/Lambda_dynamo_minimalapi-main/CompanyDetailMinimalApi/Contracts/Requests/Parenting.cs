﻿namespace CompanyDetailMinimalApi.Contracts.Requests
{
    public class Parenting
    {
        public bool? Enabled { get; set; }
        public List<string> Partners { get; set; }
    }
}
