﻿namespace PartnerApi.Contracts.Data
{
    public static class PartnerTypes
    {
        public static string Caregiving = "Caregiving";
        public static int CaregivingId = 1;

        public static string Parenting = "Parenting";
        public static int ParentingId = 2;
        
    }
}
