﻿namespace PartnerApi.Contracts.Data
{
    public class PartnerDetailDto
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public int TypeId { get; set; }
        public string Name { get; set; }

    }

}
