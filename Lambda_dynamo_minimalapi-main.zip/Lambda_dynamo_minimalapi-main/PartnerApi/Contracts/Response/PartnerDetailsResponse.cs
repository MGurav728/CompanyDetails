﻿namespace PartnerApi.Contracts.Response
{
    public class PartnerDetailsResponse
    {
        public List<string> Caregiving { get; set; }
        public List<string> Parenting { get; set; }
    }
}
